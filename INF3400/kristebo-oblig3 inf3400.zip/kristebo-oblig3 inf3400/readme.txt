det har bare vært problemer med latex for meg i dag. så rapporten er noe avstumpa. Har rett og slett prioritert feil og ikke fått itd til å skrive en skikkelig rapport, men jeg leverer det jeg har.

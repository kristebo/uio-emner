function [ vout ] = gpib_function(  )

HPE3631_Init;
HPE3631_SetILimit(1,0.1);
%HPE3631_SetVolt(1,1);
HPE3631_Operate;


HP34401_Init;
vout=zeros(1,10)';
HP34401_SetRange(0)
n=1;
i=linspace(1,6,10);
for k=1:len(i)
   HPE3631_SetVolt(1,i(k));
   HP34401_SetMode('AD');
   pause(0.5);
   vout(k) = HP34401_ReadQuick(06);
end
plot(i,vout)
end

